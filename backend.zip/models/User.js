const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true },
    email: { type: String, trim: true, lowercase: true },
    password: { type: String, required: true, minlength: 6, select: false },
    role: {
      type: String,
      enum: ['superadmin', 'admin', 'delivery'],
      required: true,
    },
    // Super Admin has no company. Admin/Delivery belong to exactly one company.
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Company',
      required: function () {
        return this.role !== 'superadmin';
      },
    },
    isActive: { type: Boolean, default: true },
    lastLoginAt: { type: Date },
  },
  { timestamps: true }
);

// Hash password before save
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.matchPassword = async function (enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

// Ensure data isolation: compound index so a phone number is unique per company
// (superadmin has no company, so allow global uniqueness for role=superadmin separately)
userSchema.index({ company: 1, phone: 1 }, { unique: true, partialFilterExpression: { company: { $exists: true } } });

module.exports = mongoose.model('User', userSchema);
